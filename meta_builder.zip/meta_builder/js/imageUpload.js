jQuery(function($){
	$('.meta-builder-imageUpload').on('click','.meta-builder-image-upload-button',function(event){
		event.preventDefault();
		
		var current_upload_box = $(this).parents('.meta-builder-imageUpload');
		var current_upload_id = $(current_upload_box).find('.meta-builder-image-id');
		var current_upload_preview = $(current_upload_box).find('.meta-builder-image-preview');
		var current_upload_button = $(current_upload_box).find('.meta-builder-image-button');
		var frame = wp.media({
		  title: 'Select or Upload Image',
		  button: {
			text: 'Use this image'
		  },
		  multiple: false 
		});
		/*
		if ( frame ) {
		  frame.open();
		  return;
		}
		*/
		frame.on( 'select', function() {
			var attachment = frame.state().get('selection').first().toJSON();
			$(current_upload_id).val(attachment.id);
			$(current_upload_preview).html("<img src='"+attachment.url+"'/>");
			$(current_upload_button).html("<button type='button' class='button meta-builder-image-remove-button'>Remove Image</button>");
		});
		
		frame.open();
		
	});
	
	$('.meta-builder-imageUpload').on('click','.meta-builder-image-remove-button',function(event){
		event.preventDefault();
		var current_upload_box = $(this).parents('.meta-builder-imageUpload');
		var current_upload_id = $(current_upload_box).find('.meta-builder-image-id');
		var current_upload_preview = $(current_upload_box).find('.meta-builder-image-preview');
		var current_upload_button = $(current_upload_box).find('.meta-builder-image-button');
		$(current_upload_id).val('');
		$(current_upload_preview).html('');
		$(current_upload_button).html("<button type='button' class='meta-builder-image-upload-button button button-primary'>Upload Image</button>");
		
	});
	
	
	$('.meta-builder-imageGalleryUpload').on('click','.meta-builder-gallery-upload-button', function(event){
		event.preventDefault();
		var current_gallery_box = $(this).parents('.meta-builder-imageGalleryUpload');
		var gallery_name = $(this).attr('data-galleryName');
		var image_list = $(current_gallery_box).find('ul');
		
		var frame = wp.media({
		  title: 'Select or Upload Image',
		  button: {
			text: 'Upload'
		  },
		  multiple: true 
		});
		
		frame.on( 'select', function() {
			var attachment = frame.state().get('selection').toJSON();
			for(var i=0; i< attachment.length; i++){
				$(image_list).append("<li><img src='"+attachment[i].url+"'/><input type='hidden' name='"+gallery_name+"[]' value='"+attachment[i].id+"'/><span class='remove'>&times;</span></li>");
				//console.log(attachment[i].id);
			}
			
		});

		frame.open();
	});
	
	$('.meta-builder-imageGalleryUpload').on('click','ul li span.remove', function(event){
		$(this).parent('li').remove();
	});
	
	$('.meta-builder-objectUpload').on('click','.meta-builder-object-upload-button', function(event){
		event.preventDefault();
		var current_object_box = $(this).parents('.meta-builder-objectUpload');
		var current_object_id = $(current_object_box).find('.meta-builder-object-id');
		var current_object_name = $(current_object_box).find('.meta-builder-object-name');
		var current_object_button = $(current_object_box).find('.meta-builder-object-button');
		
		var frame = wp.media({
			title: 'Select or Upload',
			button: {
				text: 'Use this media'
			},
			multiple: false 
		});
		
		frame.on( 'select', function() {
			var attachment = frame.state().get('selection').first().toJSON();
			$(current_object_name).val(attachment.filename);
			$(current_object_id).val(attachment.id);
			$(current_object_button).html("<button type='button' class='button meta-builder-object-remove-button'>Remove File</button>");			
		});

		frame.open();
	});
	
	$('.meta-builder-objectUpload').on('click','.meta-builder-object-remove-button', function(event){
		event.preventDefault();
		var current_object_box = $(this).parents('.meta-builder-objectUpload');
		var current_object_id = $(current_object_box).find('.meta-builder-object-id');
		var current_object_name = $(current_object_box).find('.meta-builder-object-name');
		var current_object_button = $(current_object_box).find('.meta-builder-object-button');
		$(current_object_name).val('');
		$(current_object_id).val('');
		$(current_object_button).html("<button type='button' class='meta-builder-object-upload-button button button-primary'>Upload File</button>");	
		
	});
	
	$(document).ready(function(){
		var defaultTab;
		
		if(!sessionStorage.getItem('meta-builder-theme-tab')){
			sessionStorage.setItem('meta-builder-theme-tab',0);
		}
		defaultTab = sessionStorage.getItem('meta-builder-theme-tab');
		$('.meta-builder-theme-option-page').find(".tab-content").eq(defaultTab).addClass('tab-active');
		$('.meta-builder-theme-option-page').find(".nav-tab-wrapper .nav-tab").eq(defaultTab).addClass('nav-tab-active');
	});
	
	$(".meta-builder-theme-option-page .nav-tab-wrapper .nav-tab").on('click',function(){
		if(!$(this).hasClass('nav-tab-active')){
			var tabPressed = $(this).index();
			sessionStorage.setItem('meta-builder-theme-tab',tabPressed);
			$('.meta-builder-theme-option-page').find(".tab-content").removeClass('tab-active');
			$('.meta-builder-theme-option-page').find(".nav-tab-wrapper .nav-tab").removeClass('nav-tab-active');
			$('.meta-builder-theme-option-page').find(".tab-content").eq(tabPressed).addClass('tab-active');
			$('.meta-builder-theme-option-page').find(".nav-tab-wrapper .nav-tab").eq(tabPressed).addClass('nav-tab-active');
		}
		
	});
	
});