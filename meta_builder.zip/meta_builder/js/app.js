jQuery(function($){

	var AJAX_URL = ajax_object.ajax_url;

	var mainContainer = $('#meta_builder_page');

	function login_meta_builder(username, password){
		var response = $('#meta-builder-login-response');
		
		var data = {
			'action':'meta_builder_ajax_handle',
			'route' : 'user/login',
			'username': username,
			'password': password
		};
			
		
		var bool = true;
		if(bool){
			$(response).html('<p class="color-green">Loading...</p>');
			bool = false;
			$.ajax({
				url: AJAX_URL,
				type: 'POST',
				dataType: 'html',
				data: data,
			})
			.done(function(data) {
				if(data=='no'){
					$(response).html('<p class="color-red">Username or password is invalid.</p>');
				}else{
					$(mainContainer).html(data);
					sessionStorage.setItem('username',username);
					sessionStorage.setItem('password',password);
				}
			})
			.fail(function() {
				$(response).html('<p class="color-red">Something went wrong.</p>');
				console.log("error");
			})
			.always(function() {
				bool = true;
				console.log("complete");
			});
		}
	}
	
	$(document).on('submit', '#meta-builder-login', function(event) {
		event.preventDefault();
		var response = $('#meta-builder-login-response');
		var username = $.trim($(this).find('input[name="meta-builder-username"]').val());
		var password = $.trim($(this).find('input[name="meta-builder-password"]').val());
		
		if(username == '' && password == ''){
			$(response).html('<p class="color-red">Username or password is empty.</p>');
		}else{
			login_meta_builder(username, password);
		}
		
	});

	$(window).load(function() {
		if(sessionStorage.getItem('username') && sessionStorage.getItem('password')){
			var username = sessionStorage.getItem('username');
			var password = sessionStorage.getItem('password');
			login_meta_builder(username, password);

		}
	});
 	
 	$(document).on('click','.meta-controls-head span.open', function(){
 		var control = $(this).parents('.meta-builder-controls');
 		
 		if(!$(this).hasClass('active')){
 			$('.meta-controls-head span.open').not(this).removeClass('active');
 			$('.meta-controls-body').not($(control).find('.meta-controls-body')).slideUp('fast');
 			$(this).addClass('active');
 			$(control).find('.meta-controls-body').slideDown('fast');
 		}else{
 			$('.meta-controls-head span.open').removeClass('active');
 			$('.meta-controls-body').slideUp('fast');
 			
 		}

 	});

 	$(document).on('submit', '.meta-controls-form', function(){
 		event.preventDefault();
 		var dash_response = $('#meta-builder-response');
 		$(dash_response).html('');
 		var post_type = $('#post_type_select').val();
 		if(typeof (post_type) === 'string'){
 			var form = $(this);
 			var control_type = $(form).find('input[name="meta-control-type"]').val();
 			var menu_order = $('#controls-list').children('li').length + 1;
 			var data;
 			//alert(post_type);
 			if(control_type == 'tab'){
 				var label = $(form).find('input[name="meta-control-label"]').val();
 				data = {
 					'action':'meta_builder_ajax_handle',
					'route' : 'controls/create/tab',
					'post_type': post_type,
					'label': label,
					'menu_order': menu_order
 				};

	 		}else if(control_type == 'textbox'){
				var label = $(form).find('input[name="meta-control-label"]').val();
				var name = $(form).find('input[name="meta-control-name"]').val();
				data = {
 					'action':'meta_builder_ajax_handle',
					'route' : 'controls/create/textbox',
					'post_type': post_type,
					'label': label,
					'name': name,
					'menu_order': menu_order
 				};
			}else if(control_type == 'textarea'){
				var label = $(form).find('input[name="meta-control-label"]').val();
				var name = $(form).find('input[name="meta-control-name"]').val();
				data = {
 					'action':'meta_builder_ajax_handle',
					'route' : 'controls/create/textarea',
					'post_type': post_type,
					'label': label,
					'name': name,
					'menu_order': menu_order
 				};
			}else if(control_type == 'wp_editor'){
				var label = $(form).find('input[name="meta-control-label"]').val();
				var name = $(form).find('input[name="meta-control-name"]').val();
				data = {
 					'action':'meta_builder_ajax_handle',
					'route' : 'controls/create/wp_editor',
					'post_type': post_type,
					'label': label,
					'name': name,
					'menu_order': menu_order
 				};
			}else if(control_type == 'checkbox'){
				var label = $(form).find('input[name="meta-control-label"]').val();
				var name = $(form).find('input[name="meta-control-name"]').val();
				data = {
 					'action':'meta_builder_ajax_handle',
					'route' : 'controls/create/checkbox',
					'post_type': post_type,
					'label': label,
					'name': name,
					'menu_order': menu_order
 				};
			}else if(control_type == 'selectbox'){
				var label = $(form).find('input[name="meta-control-label"]').val();
				var name = $(form).find('input[name="meta-control-name"]').val();
				var options = $(form).find('textarea[name="meta-control-options"]').val();
				data = {
 					'action':'meta_builder_ajax_handle',
					'route' : 'controls/create/selectbox',
					'post_type': post_type,
					'label': label,
					'name': name,
					'options' : options,
					'menu_order': menu_order
 				};
			}else if(control_type == 'imageUpload' || control_type == 'imageGalleryUpload'|| control_type == 'objectUpload'){
				var label = $(form).find('input[name="meta-control-label"]').val();
				var name = $(form).find('input[name="meta-control-name"]').val();
				var message = $(form).find('textarea[name="meta-control-message"]').val();
				data = {
 					'action':'meta_builder_ajax_handle',
					'route' : 'controls/create/uploader',
					'post_type': post_type,
					'label': label,
					'name': name,
					'message' : message,
					'control_type' : control_type,
					'menu_order': menu_order
 				};
			}
				$(dash_response).html('<p class="color-green">Loading...</p>');

			
				$.ajax({
 					url: AJAX_URL,
 					type: 'POST',
 					dataType: 'html',
 					data: data,
 				})
 				.done(function(data) {
 					if(data=='ok'){
						$(form)[0].reset();
						reload_control_list();
						$(dash_response).html('');
					}else if(data == 'already'){
						$(dash_response).html('<p class="color-yellow">Variable name already exist for this post type.</p>');
					}else{
						$(dash_response).html('<p class="color-red">Something went wrong.</p>');
					}
 				})
 				.fail(function() {
 					console.log("error");
 				})
 				.always(function() {
					
 				});
 		}else{
 			$(dash_response).html('<p class="color-red">Select a post type.</p>');
 		}
 		
 		
 	});

	function load_list(){
		var dash_response = $('#meta-builder-response');
		$(dash_response).html('');
		
		var list = document.getElementById("controls-list");
		Sortable.create(list,{
			animation: 150,
			handle: ".handle",
			filter: '.js-remove',
			onFilter: function (evt) {
				var r = confirm('Do you want to delete this control?');
				if(r){
					evt.item.parentNode.removeChild(evt.item);
					var removeControlId = $(evt.item).attr('data-control-id');
					console.log(removeControlId);
					var data = {
						'action':'meta_builder_ajax_handle',
						'route' : 'remove/control',
						'removeControlId': removeControlId
					};
					$(dash_response).html('<p class="color-green">Loading...</p>');

					$.ajax({
						url: AJAX_URL,
						type: 'POST',
						dataType: 'html',
						data: data,
					})
					.done(function(data) {
						console.log(data);
					})
					.fail(function() {
						console.log("error");
					})
					.always(function() {
						$(dash_response).html('');
						console.log("complete");
					});
				}
			},
			onEnd: function(evt){
				var menuOrder = [];
				$(list).children('li[data-control-id]').each(function(){
					var controlId = $(this).attr('data-control-id');
					var index = $(this).index() + 1;
					menuOrder.push( {
						'controlId': controlId,
						'index' : index
					});
				});
				//console.log(menuOrder);
				menuOrder = JSON.stringify(menuOrder);
				var data = {
					'action':'meta_builder_ajax_handle',
					'route' : 'update/order',
					'menu_order': menuOrder
				};
				$(dash_response).html('<p class="color-green">Loading...</p>');
				$.ajax({
					url: AJAX_URL,
					type: 'POST',
					dataType: 'html',
					data: data,
				})
				.done(function(data) {
					console.log(data);
				})
				.fail(function() {
					console.log("error");
				})
				.always(function() {
					$(dash_response).html('');
					console.log("complete");
				});
			}
		
		});
	}

	function reload_control_list(){
		var dash_response = $('#meta-builder-response');
 		$(dash_response).html('');
		var post_type = $('#post_type_select').val();

		if(typeof(post_type) === 'string'){
			$(dash_response).html('<p class="color-green">Loading...</p>');

			var data = {
 				'action':'meta_builder_ajax_handle',
				'route' : 'get/controls',
				'post_type': post_type
 			};

 			$.ajax({
 				url: AJAX_URL,
 				type: 'POST',
 				dataType: 'html',
 				data: data,
 			})
 			.done(function(data) {
 				$('#meta-builder-dashboard-main').html(data);
 				load_list();
 			})
 			.fail(function() {
 				console.log("error");
 				$(dash_response).html('<p class="color-red">Something went wrong.</p>');

 			})
 			.always(function() {
 				$(dash_response).html('');

 				console.log("complete");
 			});
 			
		}
	}
	
 	$(document).on('change', '#post_type_select', function(event) {
 		reload_control_list();

 	});
	
	$(document).on('submit', '.meta-controls-update-form', function(){
 		event.preventDefault();
 		var dash_response = $('#meta-builder-response');
		$(dash_response).html('');
		var form = $(this);		
		var controlId = $(form).find('input[name="meta-control-id"]').val();
		if(controlId != ''){
			var control_type = $(form).find('input[name="meta-control-type"]').val();
			if(control_type !=''){
				var data;
				if((control_type == 'tab') || (control_type == 'textbox')|| (control_type == 'textarea')|| (control_type == 'wp_editor')|| (control_type == 'checkbox')){
					var label = $(form).find('input[name="meta-control-label"]').val();
					data = {
						'action':'meta_builder_ajax_handle',
						'route' : 'controls/update/controlLabel',
						'label': label,
						'controlId': controlId
					};
					
				}else if(control_type == 'selectbox'){
					var label = $(form).find('input[name="meta-control-label"]').val();
					var options = $(form).find('textarea[name="meta-control-options"]').val();
					data = {
						'action':'meta_builder_ajax_handle',
						'route' : 'controls/update/selectData',
						'label': label,
						'controlId': controlId,
						'options' : options
					};
				}else if(control_type == 'imageUpload' || control_type == 'imageGalleryUpload'|| control_type == 'objectUpload'){
					var label = $(form).find('input[name="meta-control-label"]').val();
					var message = $(form).find('textarea[name="meta-control-message"]').val();
					data = {
						'action':'meta_builder_ajax_handle',
						'route' : 'controls/update/uploaderData',
						'label': label,
						'message' : message,
						'controlId': controlId
					};
				}
					//console.log(data);
				$(dash_response).html('<p class="color-green">Loading...</p>');
				$.ajax({
					url: AJAX_URL,
					type: 'POST',
					dataType: 'html',
					data: data,
				})
				.done(function(data) {
					$(dash_response).html('');
					
				})
				.fail(function() {
					console.log("error");
				})
				.always(function() {
					
				});
			}
		}
		
	});
 	
});