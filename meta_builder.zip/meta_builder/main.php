<?php
/*

Plugin Name: WP Meta Builder
Plugin URI: https://github.com/ImDR/Meta-Builder
Description: Meta Builder
Version: 2017
Author: Dinesh Rawat
Author URI: https://imdr.github.io/

*/

define(MB_DIR, plugin_dir_url(__FILE__));

include_once('classes/controls.php');
include_once('classes/Template.php');
include_once('classes/Users.php');
include_once('classes/Router.php');
include_once('classes/ajax_action.php');

include_once('meta_builder.php');
include_once('meta_builder_theme.php');




register_activation_hook( __FILE__, 'meta_builder_setup');

function meta_builder_setup(){
	$user = new MB_User();
	$user->default_user();

	global $wpdb;
	$charset = $wpdb->get_charset_collate();
	$table_name = $wpdb->prefix.'meta_builder_db';

	if($wpdb->get_var("show tables like '$table_name'") != $table_name){
		$sql = "CREATE TABLE $table_name ( 
			`object_id` INT NOT NULL AUTO_INCREMENT , 
			`meta_name` TEXT NOT NULL , 
			`meta_label` TEXT NOT NULL , 
			`meta_value` TEXT NOT NULL , 
			`meta_type` TEXT NOT NULL , 
			`post_type` TEXT NOT NULL , 
			`options` TEXT NOT NULL , 
			`parent_id` INT NOT NULL ,
			PRIMARY KEY (`object_id`)
		) $charset;";
		require_once(ABSPATH.'wp-admin/includes/upgrade.php');
		dbDelta($sql);
	}
	
}

register_uninstall_hook(__FILE__, 'meta_builder_remove' );

function meta_builder_remove(){
	$user = new MB_User();
	$user->delete_user();
}


add_action( 'admin_init', 'meta_builder_scripts' );

function meta_builder_scripts(){
	wp_enqueue_media();
	wp_enqueue_style( 'meta_builder_style', MB_DIR.'css/style.css', array(), '1.0' );
	
	wp_enqueue_script('jquery');

	wp_enqueue_script( 'meta_builder_imageUpload', MB_DIR.'js/imageUpload.js', array('jquery'), '1.0', true );
	wp_enqueue_script( 'Sortable', MB_DIR.'js/Sortable.min.js', array('jquery'), '1.0', true );
	wp_enqueue_script( 'meta_builder_script', MB_DIR.'js/app.js', array('jquery'), '1.0', true );
	wp_localize_script( 'meta_builder_script', 'ajax_object', array('ajax_url'=> admin_url('admin-ajax.php')) );
}
