<?php

class MB_User {
	public function login($username = '', $password = ''){
		if((get_option( 'meta_builder_username')== trim($username)) && (get_option( 'meta_builder_password') == md5(trim($password)))){
			return true;
		}
		return false;
	}

	public function default_user(){
		update_option('meta_builder_username', 'developer');
		update_option('meta_builder_password', md5('developer'));
		update_option('meta_builder_defaultuser', 'true');
	}

	public function check_default(){
		if(get_option( 'meta_builder_defaultuser') == 'true'){
			return true;
		}
		return false;
	}

	public function change_login($username, $password){
		update_option('meta_builder_username', $username);
		update_option('meta_builder_password',  md5(trim($password)));
		update_option('meta_builder_defaultuser', 'false');
	}

	public function delete_user(){
		delete_option('meta_builder_username');
		delete_option('meta_builder_password');
		delete_option('meta_builder_defaultuser');
	}
}