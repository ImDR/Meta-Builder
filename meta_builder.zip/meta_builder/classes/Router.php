<?php

class MB_Router{
	private function match_url($key, $value){
		$key = explode("/", trim($key,'/'));
		$value = explode("/", trim($value,'/'));

		if(count($key) == count($value)){
			foreach ($key as $k => $v) {
				if($v == $value[$k]){
					if($k == (count($key) - 1)){
						return true;
					}
				}
			}
		}
		return false;
	}

	public function route($key, $value, $callback){
		
		if($this->match_url($key, $value) && is_callable($callback)){
			$callback();
		}
		
	}
}