<?php

class MB_Template{
	public function dashboard(){
		?>
	<div class="meta-builder-container">
		<div class="meta-builder-dashboard-menu card">
			<h1>Meta Builder</h1>
			<div class="meta-builder-field">
				<h4>All Post Types:</h4>
				<select id="post_type_select">
					<option selected disabled>-- Select Post Type --</option>
					<option value="theme">theme option</option>
				<?php

				foreach (get_post_types(array('public'=>true)) as $post) {
					if($post == 'attachment') continue;
					echo "<option value='". $post ."'>" . $post . "</option>";
				}
				?>
				</select>
			</div>
			<div id="meta-builder-response"></div>
			<hr/>
			<h1>Controls</h1>
			<div class="meta-builder-controls">
				<div class="meta-controls-head">
					<h4>Tab</h4>
					<span class="open"><img src="<?php echo MB_DIR; ?>img/chevron-down.png"/></span>
				</div>
				<div class="meta-controls-body">
					<form method="post" class="meta-controls-form">
						<div class="meta-builder-field">
							<input type="text" name="meta-control-label" placeholder="Label" required />
						</div>
						<input type="hidden" name="meta-control-type" value="tab">
						<input type="submit" class="btn bgcolor-red" value="Save">
						<button type="reset" class="btn" >Clear</button>
					</form>
				</div>
			</div>
			<div class="meta-builder-controls">
				<div class="meta-controls-head">
					<h4>Textbox</h4>
					<span class="open"><img src="<?php echo MB_DIR; ?>img/chevron-down.png"/></span>
				</div>
				<div class="meta-controls-body">
					<form method="post" class="meta-controls-form">
						<div class="meta-builder-field">
							<input type="text" name="meta-control-name" pattern="[a-zA-Z0-9_]+" title="only a-z, A-Z, 0-9 and _" placeholder="Variable Name" required />
						</div>
						<div class="meta-builder-field">
							<input type="text" name="meta-control-label" placeholder="Label" required />
						</div>
						<input type="hidden" name="meta-control-type" value="textbox">
						<input type="submit" class="btn bgcolor-green" value="Save">
						<button type="reset" class="btn" >Clear</button>
					</form>
				</div>
			</div>
			<div class="meta-builder-controls">
				<div class="meta-controls-head">
					<h4>Textarea</h4>
					<span class="open"><img src="<?php echo MB_DIR; ?>img/chevron-down.png"/></span>
				</div>
				<div class="meta-controls-body">
					<form method="post" class="meta-controls-form">
						<div class="meta-builder-field">
							<input type="text" name="meta-control-name" pattern="[a-zA-Z0-9_]+" title="only a-z, A-Z, 0-9 and _" placeholder="Variable Name" required />
						</div>
						<div class="meta-builder-field">
							<input type="text" name="meta-control-label" placeholder="Label" required />
						</div>
						<input type="hidden" name="meta-control-type" value="textarea">
						<input type="submit" class="btn bgcolor-blue" value="Save">
						<button type="reset" class="btn" >Clear</button>
					</form>
				</div>
			</div>
			<div class="meta-builder-controls">
				<div class="meta-controls-head">
					<h4>WP Editor</h4>
					<span class="open"><img src="<?php echo MB_DIR; ?>img/chevron-down.png"/></span>
				</div>
				<div class="meta-controls-body">
					<form method="post" class="meta-controls-form">
						<div class="meta-builder-field">
							<input type="text" name="meta-control-name" pattern="[a-zA-Z0-9_]+" title="only a-z, A-Z, 0-9 and _" placeholder="Variable Name" required />
						</div>
						<div class="meta-builder-field">
							<input type="text" name="meta-control-label" placeholder="Label" required />
						</div>
						<input type="hidden" name="meta-control-type" value="wp_editor">
						<input type="submit" class="btn bgcolor-yellow" value="Save">
						<button type="reset" class="btn" >Clear</button>
					</form>
				</div>
			</div>
			<div class="meta-builder-controls">
				<div class="meta-controls-head">
					<h4>Checkbox</h4>
					<span class="open"><img src="<?php echo MB_DIR; ?>img/chevron-down.png"/></span>
				</div>
				<div class="meta-controls-body">
					<form method="post" class="meta-controls-form">
						<div class="meta-builder-field">
							<input type="text" name="meta-control-name" pattern="[a-zA-Z0-9_]+" title="only a-z, A-Z, 0-9 and _" placeholder="Variable Name" required />
						</div>
						<div class="meta-builder-field">
							<input type="text" name="meta-control-label" placeholder="Label" required />
						</div>
						<input type="hidden" name="meta-control-type" value="checkbox">
						<input type="submit" class="btn bgcolor-red" value="Save">
						<button type="reset" class="btn" >Clear</button>
					</form>
				</div>
			</div>
			<div class="meta-builder-controls">
				<div class="meta-controls-head">
					<h4>Selectbox</h4>
					<span class="open"><img src="<?php echo MB_DIR; ?>img/chevron-down.png"/></span>
				</div>
				<div class="meta-controls-body">
					<form method="post" class="meta-controls-form">
						<div class="meta-builder-field">
							<input type="text" name="meta-control-name" pattern="[a-zA-Z0-9_]+" title="only a-z, A-Z, 0-9 and _" placeholder="Variable Name" required />
						</div>
						<div class="meta-builder-field">
							<input type="text" name="meta-control-label" placeholder="Label" required />
						</div>
						<div class="meta-builder-field">
							<textarea rows="5" style="resize:none;" name="meta-control-options" placeholder='"option1", "option2"'></textarea>
						</div>
						<input type="hidden" name="meta-control-type" value="selectbox">
						<input type="submit" class="btn bgcolor-green" value="Save">
						<button type="reset" class="btn" >Clear</button>
					</form>
				</div>
			</div>
			<div class="meta-builder-controls">
				<div class="meta-controls-head">
					<h4>ImageUpload</h4>
					<span class="open"><img src="<?php echo MB_DIR; ?>img/chevron-down.png"/></span>
				</div>
				<div class="meta-controls-body">
					<form method="post" class="meta-controls-form">
						<div class="meta-builder-field">
							<input type="text" name="meta-control-name" pattern="[a-zA-Z0-9_]+" title="only a-z, A-Z, 0-9 and _" placeholder="Variable Name" required />
						</div>
						<div class="meta-builder-field">
							<input type="text" name="meta-control-label" placeholder="Label" required />
						</div>
						<div class="meta-builder-field">
							<textarea rows="5" style="resize:none;" name="meta-control-message" placeholder='Message'></textarea>
						</div>
						<input type="hidden" name="meta-control-type" value="imageUpload">
						<input type="submit" class="btn bgcolor-blue" value="Save">
						<button type="reset" class="btn" >Clear</button>
					</form>
				</div>
			</div>
			<div class="meta-builder-controls">
				<div class="meta-controls-head">
					<h4>ImageGalleryUpload</h4>
					<span class="open"><img src="<?php echo MB_DIR; ?>img/chevron-down.png"/></span>
				</div>
				<div class="meta-controls-body">
					<form method="post" class="meta-controls-form">
						<div class="meta-builder-field">
							<input type="text" name="meta-control-name" pattern="[a-zA-Z0-9_]+" title="only a-z, A-Z, 0-9 and _" placeholder="Variable Name" required />
						</div>
						<div class="meta-builder-field">
							<input type="text" name="meta-control-label" placeholder="Label" required />
						</div>
						<div class="meta-builder-field">
							<textarea rows="5" style="resize:none;" name="meta-control-message" placeholder='Message'></textarea>
						</div>
						<input type="hidden" name="meta-control-type" value="imageGalleryUpload">
						<input type="submit" class="btn bgcolor-yellow" value="Save">
						<button type="reset" class="btn" >Clear</button>
					</form>
				</div>
			</div>
			<div class="meta-builder-controls">
				<div class="meta-controls-head">
					<h4>ObjectUpload</h4>
					<span class="open"><img src="<?php echo MB_DIR; ?>img/chevron-down.png"/></span>
				</div>
				<div class="meta-controls-body">
					<form method="post" class="meta-controls-form">
						<div class="meta-builder-field">
							<input type="text" name="meta-control-name" pattern="[a-zA-Z0-9_]+" title="only a-z, A-Z, 0-9 and _" placeholder="Variable Name" required />
						</div>
						<div class="meta-builder-field">
							<input type="text" name="meta-control-label" placeholder="Label" required />
						</div>
						<div class="meta-builder-field">
							<textarea rows="5" style="resize:none;" name="meta-control-message" placeholder='Message'></textarea>
						</div>
						<input type="hidden" name="meta-control-type" value="objectUpload">
						<input type="submit" class="btn bgcolor-red" value="Save">
						<button type="reset" class="btn" >Clear</button>
					</form>
				</div>
			</div>
			<div id="meta-builder-footer">Developed by: <a href="http://imdr.github.io/">Dinesh Rawat</a></div>
		</div>
		<div class="meta-builder-dashboard-main" id="meta-builder-dashboard-main">
			
		</div>
	</div>
	<?php
	}


	public function getControls($post_type){
		?>
		<div class="card" >
			<h2>Post Type: <?php echo $post_type; ?></h2>
			<ol id="controls-list" data-post-type="<?php echo $post_type; ?>">
			<?php
				$controls = new MB_Controls();
				$results = $controls->getControlsByPostType($post_type);
				if(count($results)>0){
					foreach($results as $item){
						$item = get_object_vars($item);
						//print_r($item);
					?>
					<li data-control-id="<?php echo $item['object_id']; ?>">
					<div class="meta-builder-controls">
						<div class="meta-controls-head">
							<h4>
							<?php echo ucwords(str_replace('_',' ', $item['meta_type'])); ?>
							<small><i>( <?php echo ($item['meta_name'] == 'tab')? $item['meta_label'] : $item['meta_name']; ?> )</i></small>
							</h4>
							
							<span class="js-remove"><img src="<?php echo MB_DIR; ?>img/close.png"></span>
							<span class="handle"><img src="<?php echo MB_DIR; ?>img/arrows.png"></span>
							<span class="open"><img src="<?php echo MB_DIR; ?>img/chevron-down.png"></span>
						</div>
						<div class="meta-controls-body">
							<form method="post" class="meta-controls-update-form">
								<div class="meta-builder-field">
									<input type="text" name="meta-control-label" placeholder="Label" required="" value="<?php echo $item['meta_label']; ?>">
								</div>
								<?php 
								if($item['meta_type'] == 'selectbox'){
								?>
								<div class="meta-builder-field">
									<textarea rows="5" style="resize:none;" name="meta-control-options" placeholder='"option1", "option2"'><?php echo stripcslashes($item['others']); ?></textarea>
								</div>
								<?php	
								}
								?>
								<?php 
								if(($item['meta_type'] == 'imageGalleryUpload')||($item['meta_type'] == 'imageUpload')||($item['meta_type'] == 'objectUpload')){
								?>
								<div class="meta-builder-field">
									<textarea rows="5" style="resize:none;" name="meta-control-message" placeholder='Message'><?php echo $item['others']; ?></textarea>
								</div>
								<?php	
								}
								?>
								<input type="hidden" name="meta-control-type" value="<?php echo $item['meta_type']; ?>">
								<input type="hidden" name="meta-control-id" value="<?php echo $item['object_id']; ?>">
								<input type="submit" class="btn bgcolor-yellow" value="Update">
							</form>
						</div>
					</div>
					</li>
					<?php
					}
				}
			?>
			</ol>
		</div>
		<?php
	}
}