<?php

class MB_Controls{
	private $db_table;
	private $db;

	function __construct(){
		global $wpdb;
		$this->db = $wpdb;
		$this->db_table = $wpdb->prefix.'meta_builder_db';
	}
	
	public function getControlsByPostType($post_type){
		$result = $this->db->get_results( "SELECT * FROM ".$this->db_table." where `post_type` = '$post_type' ORDER BY `meta_order` ASC" );
		return $result;
	}
	
	public function createTab($label, $post_type, $order){
		$result = $this->db->insert($this->db_table, array('meta_name' => 'tab', 'meta_label' => $label, 'post_type' => $post_type, 'meta_type'=> 'tab', 'meta_order'=> $order));
		return $result;
	}
	
	public function createTextbox($label, $name, $post_type, $order){
		$result = $this->db->insert($this->db_table, array('meta_name' => $name, 'meta_label' => $label, 'post_type' => $post_type, 'meta_type'=> 'textbox', 'meta_order'=> $order));
		return $result;
	}
	
	public function createTextarea($label, $name, $post_type, $order){
		$result = $this->db->insert($this->db_table, array('meta_name' => $name, 'meta_label' => $label, 'post_type' => $post_type, 'meta_type'=> 'textarea', 'meta_order'=> $order));
		return $result;
	}
	
	public function createWpEditor($label, $name, $post_type, $order){
		$result = $this->db->insert($this->db_table, array('meta_name' => $name, 'meta_label' => $label, 'post_type' => $post_type, 'meta_type'=> 'wp_editor', 'meta_order'=> $order));
		return $result;
	}
	
	public function createCheckbox($label, $name, $post_type, $order){
		$result = $this->db->insert($this->db_table, array('meta_name' => $name, 'meta_label' => $label, 'post_type' => $post_type, 'meta_type'=> 'checkbox', 'meta_order'=> $order));
		return $result;
	}
	
	public function createSelectbox($label, $name, $options='', $post_type, $order){
		$result = $this->db->insert($this->db_table, array('meta_name' => $name, 'meta_label' => $label, 'post_type' => $post_type, 'meta_type'=> 'selectbox', 'meta_order'=> $order, 'others'=> $options));
		return $result;
	}
	
	public function createUploader($label, $name, $message='', $control_type, $post_type, $order){
		$result = $this->db->insert($this->db_table, array('meta_name' => $name, 'meta_label' => $label, 'post_type' => $post_type, 'meta_type'=> $control_type, 'meta_order'=> $order, 'others'=> $message));
		return $result;
	}
	
	public function checkControlExist($name, $post_type){
		$result = $this->db->get_results("SELECT * FROM ". $this->db_table ." where meta_name = '$name' and post_type = '$post_type' and meta_type != 'tab'");
		if (count($result) > 0){
			return true;
		}
		return false;
	}
	
	public function updateControlOrder($controlId, $order){
		$result = $this->db->update($this->db_table, array('meta_order'=>$order), array('object_id'=>$controlId));
	}
	
	public function updateLabelById($controlId, $label){
		$result = $this->db->update($this->db_table, array('meta_label'=>$label), array('object_id'=>$controlId));
		return $result;
	}
	
	public function updateLabelOthersById($controlId, $label, $options){
		$result = $this->db->update($this->db_table, array('meta_label'=>$label, 'others'=> $options), array('object_id'=>$controlId));
		return $result;
	}
	
	public function removeControlById($controlId){
		$result = $this->db->delete($this->db_table, array('object_id'=>$controlId));
		return $result;
	}
	
	public function checkPostHasMeta($post_type){
		$result = $this->db->get_var("SELECT count(*) FROM ". $this->db_table ." where post_type = '$post_type'");
		if($result>0){
			return true;
		}
		return false;
	}
}