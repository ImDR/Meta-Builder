<?php

add_action('admin_init','meta_builder_ajax_fun');

function meta_builder_ajax_fun(){
	add_action('wp_ajax_meta_builder_ajax_handle','meta_builder_ajax_handle');	
}


function meta_builder_ajax_handle(){

	$router = new MB_Router();
	
	$router->route('user/login', $_POST['route'] ,function(){
		$user = new MB_User();
		if($user->login($_POST['username'], $_POST['password'])){
			$tpl = new MB_Template();
			$tpl->dashboard();
			//meta_builder_dashboard();
		}else{
			echo "no";
		}
		
	});
	
	$router->route('get/controls', $_POST['route'] ,function(){
		$tpl = new MB_Template();
		$tpl->getControls($_POST['post_type']);
	});

	$router->route('controls/create/tab', $_POST['route'] ,function(){
		$control = new MB_Controls();
		$result = $control->createTab($_POST['label'], $_POST['post_type'], $_POST['menu_order']);
		if($result){
			echo "ok";
		}else{
			echo "error";
		}
	});
	
	$router->route('controls/create/textbox', $_POST['route'] ,function(){
		$control = new MB_Controls();
		if($control->checkControlExist($_POST['name'], $_POST['post_type'])){
			echo "already";
		}else{
			$result = $control->createTextbox($_POST['label'], $_POST['name'], $_POST['post_type'], $_POST['menu_order']);
			
			if($result){
				echo "ok";
			}else{
				echo "error";
			}
		}
	});
	
	$router->route('controls/create/textarea', $_POST['route'] ,function(){
		
		$control = new MB_Controls();
		if($control->checkControlExist($_POST['name'], $_POST['post_type'])){
			echo "already";
		}else{
			$result = $control->createTextarea($_POST['label'], $_POST['name'], $_POST['post_type'], $_POST['menu_order']);
		
			if($result){
				echo "ok";
			}else{
				echo "error";
			}
		}
	});
	
	$router->route('controls/create/wp_editor', $_POST['route'] ,function(){
		
		$control = new MB_Controls();
		if($control->checkControlExist($_POST['name'], $_POST['post_type'])){
			echo "already";
		}else{
			$result = $control->createWpEditor($_POST['label'], $_POST['name'], $_POST['post_type'], $_POST['menu_order']);
		
			if($result){
				echo "ok";
			}else{
				echo "error";
			}
		}
	});
	
	$router->route('controls/create/checkbox', $_POST['route'] ,function(){
		
		$control = new MB_Controls();
		if($control->checkControlExist($_POST['name'], $_POST['post_type'])){
			echo "already";
		}else{
			$result = $control->createCheckbox($_POST['label'], $_POST['name'], $_POST['post_type'], $_POST['menu_order']);
		
			if($result){
				echo "ok";
			}else{
				echo "error";
			}
		}
	});
	
	$router->route('controls/create/selectbox', $_POST['route'] ,function(){
		
		$control = new MB_Controls();
		if($control->checkControlExist($_POST['name'], $_POST['post_type'])){
			echo "already";
		}else{
			$result = $control->createSelectbox($_POST['label'], $_POST['name'], $_POST['options'], $_POST['post_type'], $_POST['menu_order']);
		
			if($result){
				echo "ok";
			}else{
				echo "error";
			}
		}
	});
	
	$router->route('controls/create/uploader', $_POST['route'] ,function(){
		
		$control = new MB_Controls();
		if($control->checkControlExist($_POST['name'], $_POST['post_type'])){
			echo "already";
		}else{
			$result = $control->createUploader($_POST['label'], $_POST['name'], $_POST['message'], $_POST['control_type'], $_POST['post_type'], $_POST['menu_order']);
			
			if($result){
				echo "ok";
			}else{
				echo "error";
			}
		}
	});
	$router->route('update/order', $_POST['route'] ,function(){
		//echo stripcslashes($_POST['menu_order']);
		
		$arr = json_decode(stripcslashes($_POST['menu_order']), true);
		$control = new MB_Controls();
		
		foreach ($arr as $item){
			$control->updateControlOrder(intval($item["controlId"]), intval($item["index"]));
		}
		
	});
	
	$router->route('controls/update/controlLabel', $_POST['route'] ,function(){
		$control = new MB_Controls();
		$result = $control->updateLabelById(intval($_POST["controlId"]), $_POST['label']);
		if($result){
			echo "ok";
		}else{
			echo "error";
		}
	});
	
	$router->route('controls/update/selectData', $_POST['route'] ,function(){
		$control = new MB_Controls();
		$result = $control->updateLabelOthersById(intval($_POST["controlId"]), $_POST['label'], $_POST['options']);
		if($result){
			echo "ok";
		}else{
			echo "error";
		}
	});
	
	$router->route('controls/update/uploaderData', $_POST['route'] ,function(){
		$control = new MB_Controls();
		$result = $control->updateLabelOthersById(intval($_POST["controlId"]), $_POST['label'], $_POST['message']);
		if($result){
			echo "ok";
		}else{
			echo "error";
		}
	});
	
	$router->route('remove/control', $_POST['route'] ,function(){
		$control = new MB_Controls();
		$result = $control->removeControlById(intval($_POST["removeControlId"]));
		if($result){
			echo "ok";
		}else{
			echo "error";
		}
	});
	wp_die();
}

