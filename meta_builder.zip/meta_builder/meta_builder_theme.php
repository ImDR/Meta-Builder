<?php

add_action( 'admin_menu', 'meta_builder_theme_menu');

function meta_builder_theme_menu(){
	add_menu_page( 'Theme Options', 'Theme Options', 'manage_options', 'meta-builder-theme', 'Mb_ThemePage', 'dashicons-star-filled', 60);
	add_action('admin_init','register_theme_option_plugin_settings');
}

function register_theme_option_plugin_settings(){
	$control = new MB_Controls();
	$allControls = $control->getControlsByPostType('theme');
	if(count($allControls)>0){
		foreach($allControls as $control){
			$control = get_object_vars($control);
			if($control['meta_type']!='tab'){
				register_setting('theme_option_plugin_settings_group', $control['meta_name']);
			}
		}
	}
	
}

function Mb_ThemePage(){
	?>
	<div class="wrap">
	<style>
	.meta-builder-theme-option-page .tab-content{
		display:none;
	}
	
	.meta-builder-theme-option-page .tab-content.tab-active{
		display:block;
	}
	
	.meta-builder-image-preview{
    width: 100px;
    margin-top: 15px;
}

.meta-builder-image-preview img{
	border: 1px solid #999999;
	width:100%;
	height:auto;
}

.meta-builder-imageGalleryUpload ul{
	display: block;
    margin: 0;	
}

.meta-builder-imageGalleryUpload ul li{
	display: inline-block;
    border: 1px solid #999;
    margin-right: 12px;
    margin-bottom: 15px;
	position: relative;
}

.meta-builder-imageGalleryUpload ul li span.remove{
	position: absolute;
    top: -10px;
    right: -10px;
    font-size: 20px;
    line-height: 18px;
    height: 22px;
    width: 22px;
    text-align: center;
    cursor: pointer;
    background: #ffffff;
    color: #999999;
    border: 1px solid #999999;
    border-radius: 50%;
}

.meta-builder-imageGalleryUpload ul li span.remove:hover{
	color:#f31313;
    border: 1px solid #f31313;
}

.meta-builder-imageGalleryUpload ul li img{
	height:100px;	
	width:100px;
	display:block;
}
	</style>
		<div class="meta-builder-theme-option-page">
		<h1>Meta Builder - Theme Options</h1>
		<form method="post" action="options.php">
			<?php
			settings_fields('theme_option_plugin_settings_group');
			do_settings_sections('theme_option_plugin_settings_group');
			
			$control = new MB_Controls();
			$allControls = $control->getControlsByPostType('theme');
			
			?>
			<h2 class="nav-tab-wrapper">
				<?php
				if(count($allControls)>0){
					foreach($allControls as $i=>$control){
						$control = get_object_vars($control);
						if($i==0){
							if($control['meta_type']!='tab'){
								echo '<span class="nav-tab">Options</span>';
							}
						}
						
						if($control['meta_type']=='tab'){
							echo '<span class="nav-tab">'.ucwords($control['meta_label']).'</span>';
						}
					}
				}
				?>
				
			</h2>
			<?php
			
			
			if(count($allControls)>0){
				$tabBool = false;
				foreach($allControls as $i=>$control){
					$control = get_object_vars($control);
					
					if(($i==0) || ($control['meta_type']=='tab')){
						if($tabBool){
							echo "</div>";
							$tabBool=false;
						}
						
						echo "<div class='tab-content card'>";
						$tabBool=true;
						
					}
					
					if($control['meta_type']=='textbox'){
						?>
						<p>
						<label for="<?php echo "textbox-".$control['object_id']; ?>"><?php echo ucwords($control['meta_label']); ?>:</label>
						<br/>
						<br/>
						<input type="text" id="<?php echo "textbox-".$control['object_id']; ?>" class="widefat" name="<?php echo $control['meta_name']; ?>" value="<?php echo get_option($control['meta_name']); ?>"/>
						</p>
						<?php
					}
					
					if($control['meta_type']=='textarea'){
						?>
						<p>
						<label for="<?php echo "textarea-".$control['object_id']; ?>"><?php echo ucwords($control['meta_label']); ?>:</label>
						<br/>
						<br/>
						<textarea class="widefat" id="<?php echo "textarea-".$control['object_id']; ?>" style="resize:none;" rows="7" name="<?php echo $control['meta_name']; ?>"><?php echo get_option($control['meta_name']); ?></textarea>
						</p>
						<?php
					}
					
					if($control['meta_type']=='wp_editor'){
						?>
						<p>
						<label><?php echo ucwords($control['meta_label']); ?>:</label>
						<br/>
						<?php
							$data = get_option($control['meta_name']);
							wp_editor( $data, $control['meta_name']);
						?>
						</p>
						<?php
					}
					
					if($control['meta_type']=='checkbox'){
						?>
						<p>
						<label for="<?php echo "checkbox-".$control['object_id']; ?>"><?php echo ucwords($control['meta_label']); ?>:</label>
						<input id="<?php echo "checkbox-".$control['object_id']; ?>" type="checkbox" name="<?php echo esc_attr($control['meta_name']); ?>" <?php echo (get_option($control['meta_name']) == 'on')?'checked':'';	?>>
						</p>
						<?php
					}
					
					if($control['meta_type']=='selectbox'){
						?>
						<p>
						<label for="<?php echo "selectbox-".$control['object_id']; ?>"><?php echo ucwords($control['meta_label']); ?>:</label>
						<?php preg_match_all('/"([^"]*)"/',stripcslashes($control['others']), $options); 
						//print_r($options);
						?>
						<select id="<?php echo "selectbox-".$control['object_id']; ?>" name="<?php echo esc_attr($control['meta_name']); ?>">
							<option>---- Select ---- </option>
							<?php
							foreach($options[1] as $option){
							?>
							<option value="<?php echo esc_attr($option); ?>" <?php echo (get_option($control['meta_name'])== $option)?'selected':''; ?>><?php echo ucwords($option); ?></option>
							<?php
							}
							?>
							
						</select>
						</p>
						<?php
					}
					
					if($control['meta_type']=='imageUpload'){
						?>
						<p><?php echo ucwords($control['meta_label']); ?>:</p>
						<div class="meta-builder-imageUpload">
							<input type="hidden" class="meta-builder-image-id" name="<?php echo esc_attr($control['meta_name']); ?>" value="<?php echo esc_attr(get_option($control['meta_name'])); ?>"/>
							
							<?php
							if(get_option($control['meta_name'])==''){
							?>
							<div class="meta-builder-image-button">
							<button type="button" class="meta-builder-image-upload-button button button-primary">Upload Image</button>
							</div>
							<div class="meta-builder-image-preview"></div>
							<?php
							}else{
							?>
							<div class="meta-builder-image-button">
							<button type='button' class='button meta-builder-image-remove-button'>Remove Image</button>
							</div>
							<div class="meta-builder-image-preview"><img src="<?php echo wp_get_attachment_url(get_option($control['meta_name'])); ?>"></div>
							<?php
							}
							
							?>
							<p><i><?php echo esc_html($control['others']); ?></i></p>
						</div>
						<hr/>
						<?php
					}
					
					if($control['meta_type']=='imageGalleryUpload'){
						?>
						<p><?php echo ucwords($control['meta_label']); ?>:</p>
						<div class="meta-builder-imageGalleryUpload">
							<ul>
							<?php
							$images = get_option($control['meta_name'], false); 
							if(count($images)>0 && $images){
								foreach($images as $image_id){
								?>
									<li>
										<img src="<?php echo wp_get_attachment_url($image_id); ?>">
										<input type="hidden" name="<?php echo $control['meta_name']; ?>[]" value="<?php echo $image_id; ?>">
										<span class="remove">&times;</span>
									</li>
								<?php
								}
							}
							?>
							</ul>
							
							<button data-galleryName="<?php echo esc_attr($control['meta_name']); ?>" type="button" class="meta-builder-gallery-upload-button button button-primary">Add Images</button>
							<p><i><?php echo esc_html($control['others']); ?></i></p>
						</div>
						<hr/>
						<?php
					}
					
					if($control['meta_type']=='objectUpload'){
						?>
						<p><?php echo ucwords($control['meta_label']); ?>:</p>
						<div class="meta-builder-objectUpload">
							<input type="hidden" class="meta-builder-object-id" name="<?php echo esc_attr($control['meta_name']); ?>" value="<?php echo get_option($control['meta_name']); ?>"/>
							<input type="text" class="widefat meta-builder-object-name" value="<?php echo basename(get_attached_file(get_option($control['meta_name']))); ?>" disabled />
							<div class="meta-builder-object-button" style="margin-top:10px;">
							<?php
							if(get_option($control['meta_name']) !=''){
							?>
							<button type="button" class="button meta-builder-object-remove-button">Remove File</button>
							<?php
							}else{
							?>
							<button type="button" class="meta-builder-object-upload-button button button-primary">Upload File</button>
							<?php
							}
							?>
							</div>		
							<p><i><?php echo esc_html($control['others']); ?></i></p>
						</div>
						<hr/>
						<?php
					}
					
					if($i == (count($allControls)-1)){
						echo "</div>";
						$tabBool=false;
					}
				}
				submit_button();
			}
			
			
			?>
		</form>
		</div>
	</div>
	<?php
}
?>