<?php

add_action( 'admin_menu', 'meta_builder_menu');

function meta_builder_menu(){
	add_menu_page( 'Developer', 'Developer', 'manage_options', 'meta-builder', 'Mb_DeveloperPage', 'dashicons-admin-appearance', 80);
}

function Mb_DeveloperPage(){
	?>
	<div class="wrap" id="meta_builder_page" >
		<div class="meta-builder-container">
			<div class="meta-builder-login card">
					<h1>Developer Login</h1>
					<form method='post' id="meta-builder-login">
						<div class="meta-builder-field">
							<input type="text" name="meta-builder-username" placeholder="Username" value=""/>
						</div>
						<div class="meta-builder-field">
							<input type="password" name="meta-builder-password" placeholder="Password" value=""/>
						</div>
						<input type="submit" class="btn bgcolor-blue" value="Login">
					</form>
					<div id="meta-builder-login-response"></div>
					<?php
					$user = new MB_User();
					if($user->check_default()){
						echo "<p class='color-blue'>Default User</p>";
						echo "<p class='color-blue'><b>Username:</b> developer</p>";
						echo "<p class='color-blue'><b>Password:</b> developer</p>";
					}

					?>
					<div id="meta-builder-footer">Developed by: <a href="http://imdr.github.io/">Dinesh Rawat</a></div>
			</div>
		</div>
	</div>
	<?php
}


add_action('add_meta_boxes','MB_Create_Metabox');

function MB_Create_Metabox(){
	global $post;
	$control = new MB_Controls();
	$result = $control->checkPostHasMeta($post->post_type);
	if($result){
		$metaBoxId = "meta-builder-".$post->post_type;
		add_meta_box($metaBoxId,'Meta Builder','MB_MetaBox_Page_Controls',$post->post_type,'normal','default');
	}
	
}

function MB_MetaBox_Page_Controls(){
	global $post;
?>
<style>
.meta-builder-image-preview{
    width: 100px;
    margin-top: 15px;
}

.meta-builder-image-preview img{
	border: 1px solid #999999;
	width:100%;
	height:auto;
}

.meta-builder-imageGalleryUpload ul{
	display: block;
    margin: 0;	
}

.meta-builder-imageGalleryUpload ul li{
	display: inline-block;
    border: 1px solid #999;
    margin-right: 12px;
    margin-bottom: 15px;
	position: relative;
}

.meta-builder-imageGalleryUpload ul li span.remove{
	position: absolute;
    top: -10px;
    right: -10px;
    font-size: 20px;
    line-height: 18px;
    height: 22px;
    width: 22px;
    text-align: center;
    cursor: pointer;
    background: #ffffff;
    color: #999999;
    border: 1px solid #999999;
    border-radius: 50%;
}

.meta-builder-imageGalleryUpload ul li span.remove:hover{
	color:#f31313;
    border: 1px solid #f31313;
}

.meta-builder-imageGalleryUpload ul li img{
	height:100px;	
	width:100px;
	display:block;
}
</style>
<?php
	wp_nonce_field(basename(__FILE__),'meta_builder_nonce');
	$control = new MB_Controls();
	$allControls = $control->getControlsByPostType($post->post_type);
	foreach($allControls as $control){
		$control = get_object_vars($control);
		//print_r($control);
		if($control['meta_type']=='tab'){
			?>
			<br/>
			<br/>
			<h1 data-control-id="<?php echo $control['object_id']; ?>"><?php echo ucwords($control['meta_label']); ?></h1>
			<hr/>
			<?php
		}
		
		if($control['meta_type']=='textbox'){
			?>
			<p>
			<label for="<?php echo "textbox-".$control['object_id']; ?>"><?php echo ucwords($control['meta_label']); ?>:</label>
			<br/>
			<input type="text" id="<?php echo "textbox-".$control['object_id']; ?>" class="widefat" name="<?php echo $control['meta_name']; ?>" value="<?php echo esc_attr(get_post_meta($post->ID, $control['meta_name'], true)); ?>"/>
			</p>
			<?php
		}
		
		if($control['meta_type']=='textarea'){
			?>
			<p>
			<label for="<?php echo "textarea-".$control['object_id']; ?>"><?php echo ucwords($control['meta_label']); ?>:</label>
			<br/>
			<textarea class="widefat" id="<?php echo "textarea-".$control['object_id']; ?>" rows="7" name="<?php echo $control['meta_name']; ?>"><?php echo esc_attr(get_post_meta($post->ID, $control['meta_name'], true)); ?></textarea>
			</p>
			<?php
		}
		
		if($control['meta_type']=='wp_editor'){
			?>
			<p>
			<label><?php echo ucwords($control['meta_label']); ?>:</label>
			<br/>
			<?php
				$data = get_post_meta($post->ID, $control['meta_name'], true);
				wp_editor( $data, $control['meta_name']);
			?>
			</p>
			<?php
		}
		
		if($control['meta_type']=='checkbox'){
			?>
			<p>
			<label for="<?php echo "checkbox-".$control['object_id']; ?>"><?php echo ucwords($control['meta_label']); ?>:</label>
			<input id="<?php echo "checkbox-".$control['object_id']; ?>" type="checkbox" name="<?php echo esc_attr($control['meta_name']); ?>" <?php echo (get_post_meta($post->ID, $control['meta_name'], true) == 'on')?'checked':'';	?>>
			</p>
			<?php
		}
		
		if($control['meta_type']=='selectbox'){
			?>
			<p>
			<label for="<?php echo "selectbox-".$control['object_id']; ?>"><?php echo ucwords($control['meta_label']); ?>:</label>
			<?php preg_match_all('/"([^"]*)"/',stripcslashes($control['others']), $options); 
			//print_r($options);
			?>
			<select id="<?php echo "selectbox-".$control['object_id']; ?>" name="<?php echo esc_attr($control['meta_name']); ?>">
				<option>---- Select ---- </option>
				<?php
				foreach($options[1] as $option){
				?>
				<option value="<?php echo esc_attr($option); ?>" <?php echo (get_post_meta($post->ID, $control['meta_name'], true)== $option)?'selected':''; ?>><?php echo ucwords($option); ?></option>
				<?php
				}
				?>
				
			</select>
			</p>
			<?php
		}
		
		if($control['meta_type']=='imageUpload'){
			?>
			<p><?php echo ucwords($control['meta_label']); ?>:</p>
			<div class="meta-builder-imageUpload">
				<input type="hidden" class="meta-builder-image-id" name="<?php echo esc_attr($control['meta_name']); ?>" value="<?php echo esc_attr(get_post_meta($post->ID, $control['meta_name'], true)); ?>"/>
				
				<?php
				if(get_post_meta($post->ID, $control['meta_name'], true)==''){
				?>
				<div class="meta-builder-image-button">
				<button type="button" class="meta-builder-image-upload-button button button-primary">Upload Image</button>
				</div>
				<div class="meta-builder-image-preview"></div>
				<?php
				}else{
				?>
				<div class="meta-builder-image-button">
				<button type='button' class='button meta-builder-image-remove-button'>Remove Image</button>
				</div>
				<div class="meta-builder-image-preview"><img src="<?php echo wp_get_attachment_url(get_post_meta($post->ID, $control['meta_name'], true)); ?>"></div>
				<?php
				}
				
				?>
				<p><i><?php echo esc_html($control['others']); ?></i></p>
			</div>
			<hr/>
			<?php
		}

		if($control['meta_type']=='imageGalleryUpload'){
			?>
			<p><?php echo ucwords($control['meta_label']); ?>:</p>
			<div class="meta-builder-imageGalleryUpload">
				<ul>
				<?php
				$images = get_post_meta($post->ID, $control['meta_name'], true); 
				if(count($images)>0){
					foreach($images as $image_id){
					?>
						<li>
							<img src="<?php echo wp_get_attachment_url($image_id); ?>">
							<input type="hidden" name="<?php echo $control['meta_name']; ?>[]" value="<?php echo $image_id; ?>">
							<span class="remove">&times;</span>
						</li>
					<?php
					}
				}
				?>
				</ul>
				
				<button data-galleryName="<?php echo esc_attr($control['meta_name']); ?>" type="button" class="meta-builder-gallery-upload-button button button-primary">Add Images</button>
				<p><i><?php echo esc_html($control['others']); ?></i></p>
			</div>
			<hr/>
			<?php
		}
		
		if($control['meta_type']=='objectUpload'){
			?>
			<p><?php echo ucwords($control['meta_label']); ?>:</p>
			<div class="meta-builder-objectUpload">
				<input type="hidden" class="meta-builder-object-id" name="<?php echo esc_attr($control['meta_name']); ?>" value="<?php echo get_post_meta($post->ID, $control['meta_name'], true); ?>"/>
				<input type="text" class="widefat meta-builder-object-name" value="<?php echo basename(get_attached_file(get_post_meta($post->ID, $control['meta_name'], true))); ?>" disabled />
				<div class="meta-builder-object-button" style="margin-top:10px;">
				<?php
				if(get_post_meta($post->ID, $control['meta_name'], true) !=''){
				?>
				<button type="button" class="button meta-builder-object-remove-button">Remove File</button>
				<?php
				}else{
				?>
				<button type="button" class="meta-builder-object-upload-button button button-primary">Upload File</button>
				<?php
				}
				?>
				</div>		
				<p><i><?php echo esc_html($control['others']); ?></i></p>
			</div>
			<hr/>
			<?php
		}
	}
	//echo "hello";
}

add_action('save_post','MB_MetaBox_save_Controls',10,2);

function MB_MetaBox_save_Controls($post_id, $post){
	if(!isset($_POST['meta_builder_nonce'])|| !wp_verify_nonce($_POST['meta_builder_nonce'], basename(__FILE__)))
		return $post_id;
	
	if(!current_user_can('edit_post', $post->ID))
		return $post_id;
	
	$control = new MB_Controls();
	$allControls = $control->getControlsByPostType($post->post_type);
	foreach($allControls as $control){
		$control = get_object_vars($control);
		update_post_meta($post_id, $control['meta_name'], $_POST[$control['meta_name']]);
		//echo $control['meta_name'];
	}
}